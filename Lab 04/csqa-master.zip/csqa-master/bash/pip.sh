/home/aistudio/data/data20158/pip.sh
pip install apex